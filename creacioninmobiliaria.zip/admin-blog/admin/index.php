<?php $page ="Inicio";
require("seguridad.php"); 
require_once("conexion.php");
include 'layout/layout.php';
?>

<img class="fondo-principal" src="images/background_admin_noticias.png" alt="">

<?php include 'layout/layoutFooter.php';?>
