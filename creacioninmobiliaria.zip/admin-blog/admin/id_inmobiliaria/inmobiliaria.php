<?php 
    $id_inmobiliaria = 4;
?>