<?php 
    define("TOKEN", "G0djURlxZf6pzhzrvMvz2lO3baOw56UqrNJREKGd-951");
?>