<footer>
    <div class="container-fluid">
        <div class="row">
            <div class="col-10 col-sm-12 text-center">
                <span>©Copyright 2020 <a href="https://www.dexcondigital.com" target="_blank">Dexcon Digital.</a> Todos los derechos reservados</span>
            </div>
        </div>
    </div>
</footer>